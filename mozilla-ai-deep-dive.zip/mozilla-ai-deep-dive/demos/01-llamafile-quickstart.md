# Llamafile Quick Demo
**Time Required:** 2-3 minutes  
**Goal:** Show how easy it is to run a local LLM

---

## Pre-Demo Setup (Done Before Presentation)

```bash
# Download a small model (before the presentation!)
curl -LO https://huggingface.co/Mozilla/Phi-3-mini-4k-instruct-llamafile/resolve/main/phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Make executable
chmod +x phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Test that it works
./phi-3-mini-4k-instruct.Q4_K_M.llamafile --version
```

**Note:** Download BEFORE the presentation! Don't make audience wait for large file download.

---

## Live Demo Script

### Part 1: Show the File (15 seconds)

```bash
# Show it's just one file
ls -lh phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Output shows something like:
# -rwxr-xr-x  1 user  staff   2.3G Dec  4 10:30 phi-3-mini-4k-instruct.Q4_K_M.llamafile
```

**Say:** "This is it - a single 2.3GB file. No Python, no dependencies, no configuration."

### Part 2: Start the Server (30 seconds)

```bash
# Start the server
./phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Server starts and displays:
# llama server listening at http://127.0.0.1:8080
```

**Say:** "I just started an AI server on my laptop. It's running locally - no internet required, no API keys, completely private."

### Part 3: Open Browser Interface (45 seconds)

1. Open browser to `http://localhost:8080`
2. Show the ChatGPT-like interface
3. Type a Medicare-relevant question:

**Example Question:**
```
Explain the difference between CPT code 99213 and 99214 for office visits.
```

**Expected Response:**
```
CPT code 99213 is for an office visit with established patients requiring
low to moderate medical decision-making, typically 20-29 minutes. CPT 99214
is for more complex visits requiring moderate to high medical decision-making,
typically 30-39 minutes. Key differences include:

1. Complexity of medical decision-making
2. Time required
3. Level of history and examination
4. Reimbursement amount (99214 pays more)
```

**Say:** "Notice the response is fast, and the data never left my laptop. For HIPAA-compliant environments, this is huge."

### Part 4: API Call (30 seconds)

Open another terminal and show API access:

```bash
# Make a curl request to the local API
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "phi-3",
    "messages": [{"role": "user", "content": "What is Medicare Part D?"}],
    "temperature": 0.7
  }'
```

**Say:** "The same model is accessible via API, so your code can integrate with it just like OpenAI or Anthropic - but it's running locally."

### Part 5: Stop Server (10 seconds)

```bash
# Press Ctrl+C to stop
^C

# Server stops cleanly
```

**Say:** "When we're done, we stop the server. Nothing installed, nothing to uninstall. That's the beauty of llamafile."

---

## Alternative Demo: Show Different Models

If you have time, demonstrate model variety:

```bash
# Show multiple llamafiles
ls -lh *.llamafile

# Output:
# phi-3-mini-4k-instruct.Q4_K_M.llamafile        (2.3GB - fast, lightweight)
# llama-3-8b-instruct.Q4_K_M.llamafile          (4.7GB - better quality)
# mistral-7b-instruct.Q4_K_M.llamafile          (4.1GB - different strengths)
```

**Say:** "Different models for different needs. Small and fast for simple tasks, larger for complex reasoning. All the same simple deployment model."

---

## Fallback Plan

**If Demo Fails:**
- Have a pre-recorded video of the demo running
- Show screenshots of the interface
- Share the browser interface from a pre-started server

**Common Issues:**
- **Port 8080 in use:** Start with `--port 8081`
- **Model doesn't start:** Ensure ~4GB free RAM
- **Slow response:** Expected on older laptops, emphasize that this is running on commodity hardware

---

## Key Points to Emphasize

1. **One File:** No installation, no dependencies
2. **Offline:** Works completely without internet
3. **Private:** Data never leaves the machine
4. **Compatible:** OpenAI-compatible API
5. **Fast Setup:** From download to running in 60 seconds

---

## Post-Demo Talking Points

"Now imagine deploying this in a secure CMS facility:
- Download once, distribute to all workstations
- No cloud dependencies, no API costs
- Perfect for processing sensitive Medicare claims
- Identical behavior on all machines
- Zero risk of data exfiltration

This is how we can bring GEM's capabilities into air-gapped environments."

---

## Resources to Share

- Download llamafiles: https://github.com/mozilla-ai/llamafile
- Documentation: https://mozilla-ai.github.io/llamafile/
- Model directory: https://github.com/Mozilla-Ocho/llamafile/wiki/Models

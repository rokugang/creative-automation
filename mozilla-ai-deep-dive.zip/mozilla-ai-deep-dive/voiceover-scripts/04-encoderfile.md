# EncoderFile Voiceover Script
**Duration:** 3 minutes  
**Visual Aid:** Architecture comparison + performance benchmarks

---

## Opening (20 seconds)
"EncoderFile is Llamafile's sibling project, but instead of packaging generative models, it packages transformer encoders - the models designed for understanding and classification rather than generation. Think BERT, RoBERTa, or sentence transformers."

## The Problem It Solves (40 seconds)
"Many AI tasks don't need text generation. For fraud detection, you often need:
- Text classification: Is this claim description suspicious?
- Similarity matching: Does this claim match known fraud patterns?
- Named entity recognition: Extract procedure codes and diagnoses from text
- Embedding generation: Convert claims into vectors for similarity search

Running full generative models for these tasks is like using a sledgehammer to hang a picture frame. Encoder models are smaller, faster, and more focused. But they traditionally come with the same dependency hell as generative models.

EncoderFile packages them into single executable binaries - typically tens to hundreds of megabytes, not gigabytes."

## Technical Architecture (45 seconds)
"EncoderFile uses ONNX Runtime for inference, ensuring broad compatibility with transformer architectures. A single encoderfile can run as:

**REST API**: Standard HTTP endpoints for microservice architectures
**gRPC Server**: For high-performance, low-latency applications
**CLI Tool**: For batch processing large datasets
**MCP Server**: Integrating with agent systems through Model Context Protocol

The binary includes the model weights, the tokenizer, and the inference engine. No Python runtime required, no package installations, no version conflicts."

## FPS2/GEM Use Case (55 seconds)
"Let me give you concrete FPS2 examples:

**Claim Similarity Detection**: Package a sentence-transformer model as an encoderfile. When a new claim arrives, generate its embedding and compare it to known fraud patterns. This can run in real-time, inline with your claims processing pipeline, with sub-millisecond latency.

**Medical Code Classification**: Train a classifier to validate CPT code and diagnosis code combinations. Package it as an encoderfile and deploy it to edge locations where claims first enter the system. This provides immediate validation before expensive GEM processing.

**PII Detection**: Create a specialized NER model for detecting patient names, addresses, and SSNs in claim text fields. Deploy it as a preprocessor before claims reach GEM's LLM, ensuring sensitive data is masked.

**Duplicate Detection**: Use embeddings to identify duplicate or near-duplicate claims faster than rule-based systems. Process millions of historical claims overnight using the CLI mode."

## Compliance Benefits (30 seconds)
"For CMS compliance, EncoderFile offers significant advantages:

**Deterministic**: The binary includes a specific model version - no risk of accidentally updating to a new model version that hasn't been validated.

**Auditable**: Single file makes security audits straightforward. No hidden dependencies.

**Air-gapped Deployment**: Works perfectly in restricted networks with no internet access.

**Minimal Attack Surface**: Smaller binaries with fewer dependencies mean fewer potential vulnerabilities."

## Performance (10 seconds)
"Because it uses ONNX Runtime, EncoderFile achieves near-native performance. For many encoder tasks, you'll see latencies under 10 milliseconds on modern CPUs."

---

## Key Talking Points to Emphasize
- **Right Tool for the Job**: Not everything needs GPT-4
- **Lightweight**: 10-100MB binaries vs multi-GB Python environments
- **Fast**: Sub-millisecond to millisecond latencies
- **Embeddable**: Drop into existing systems without refactoring
- **Compliance-Friendly**: Deterministic, auditable, offline-capable

## Transition to Next Section
"Now we've covered the core infrastructure tools. Let's shift to safety and agent frameworks, starting with AnyGuardrail - because no AI system should go to production without proper safety controls..."

# Mozilla AI Stack Architecture Diagrams
**For FPS2 Deep Dive Presentation**

---

## Diagram 1: Complete Mozilla AI Stack

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Mozilla AI Choice-First Stack                   │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         EVALUATION LAYER                            │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                    LUMIGATOR                             │     │
│  │  • Model evaluation & comparison                         │     │
│  │  • Bias detection                                        │     │
│  │  • Cost/performance optimization                         │     │
│  └──────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         APPLICATION LAYER                           │
│                                                                     │
│  ┌─────────────────────┐    ┌────────────────────────────────┐    │
│  │    BLUEPRINTS       │    │      YOUR APPLICATION          │    │
│  │  • Pre-built        │    │    (e.g., GEM System)         │    │
│  │    workflows        │    │                                │    │
│  │  • Best practices   │    │                                │    │
│  └─────────────────────┘    └────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         ORCHESTRATION LAYER                         │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                     ANY-AGENT                            │     │
│  │  Framework-agnostic agent abstraction                    │     │
│  │  (LangChain, CrewAI, TinyAgent, etc.)                   │     │
│  └──────────────────────────────────────────────────────────┘     │
│                              │                                      │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                       MCPD                               │     │
│  │  Tool server orchestration & management                  │     │
│  └──────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         SAFETY LAYER                                │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                   ANY-GUARDRAIL                          │     │
│  │  Unified interface for AI safety guardrails              │     │
│  │  (Lakera, Llama Guard, Azure Safety, etc.)             │     │
│  └──────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         MODEL LAYER                                 │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                     ANY-LLM                              │     │
│  │  Unified LLM interface for all providers                 │     │
│  └──────────────────────────────────────────────────────────┘     │
│                              │                                      │
│  ┌────────────┬─────────────┼─────────────┬──────────────┐        │
│  │            │              │             │              │        │
│  ▼            ▼              ▼             ▼              ▼        │
│  OpenAI    Anthropic      Google       Mistral        Local       │
│  (GPT-4)   (Claude)     (Gemini)     (Mistral)    (Llamafile)    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                    SPECIALIZED MODEL LAYER                          │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────┐     │
│  │                   ENCODERFILE                            │     │
│  │  Lightweight transformer encoders                        │     │
│  │  (Classification, embeddings, NER)                       │     │
│  └──────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Diagram 2: GEM Integration with Mozilla AI Stack

```
                    ┌───────────────────────┐
                    │   Medicare Claim      │
                    │   Input Stream        │
                    └───────────┬───────────┘
                                │
                    ┌───────────▼───────────┐
                    │   Pre-Processing      │
                    │   • Validation        │
                    │   • Normalization     │
                    └───────────┬───────────┘
                                │
                ┌───────────────▼───────────────┐
                │      ANY-GUARDRAIL            │
                │   Input Safety Check          │
                └───────────────┬───────────────┘
                                │
                    ┌───────────▼──────────┐
                    │   MCPD Daemon        │
                    │   Tool Orchestration │
                    └───────────┬──────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
┌───────▼────────┐   ┌─────────▼────────┐   ┌─────────▼────────┐
│ Claims Database│   │ Policy Documents │   │ Provider Lookup  │
│ MCP Server     │   │ (RAG/Vector DB)  │   │ (NPPES API)     │
└───────┬────────┘   └─────────┬────────┘   └─────────┬────────┘
        │                       │                       │
        └───────────────────────┼───────────────────────┘
                                │
                    ┌───────────▼──────────┐
                    │    ANY-AGENT         │
                    │    (GEM Logic)       │
                    │                      │
                    │  ┌────────────────┐ │
                    │  │  Orchestrator  │ │
                    │  └────────┬───────┘ │
                    │           │         │
                    │  ┌────────▼───────┐ │
                    │  │ Specialist     │ │
                    │  │ Agents         │ │
                    │  │ • Medical      │ │
                    │  │ • Billing      │ │
                    │  │ • Compliance   │ │
                    │  └────────┬───────┘ │
                    └───────────┼─────────┘
                                │
                    ┌───────────▼──────────┐
                    │      ANY-LLM         │
                    │   Model Selection    │
                    └───────────┬──────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
┌───────▼────────┐   ┌─────────▼────────┐   ┌─────────▼────────┐
│  Complex       │   │  Medium          │   │  Simple          │
│  Claims        │   │  Claims          │   │  Claims          │
│  → GPT-4o      │   │  → Claude-3.5    │   │  → GPT-4o-mini   │
│  or Llamafile  │   │                  │   │  or Local Model  │
└───────┬────────┘   └─────────┬────────┘   └─────────┬────────┘
        │                       │                       │
        └───────────────────────┼───────────────────────┘
                                │
                    ┌───────────▼──────────┐
                    │   ENCODERFILE        │
                    │   Fast Classification│
                    │   • Fraud patterns   │
                    │   • Similarity       │
                    └───────────┬──────────┘
                                │
                    ┌───────────▼──────────┐
                    │   ANY-GUARDRAIL      │
                    │   Output Safety Check│
                    └───────────┬──────────┘
                                │
                    ┌───────────▼──────────┐
                    │   GEM Decision       │
                    │   • Approve          │
                    │   • Deny             │
                    │   • Suspend          │
                    │   + Reasoning        │
                    └──────────────────────┘
```

---

## Diagram 3: Offline/Air-Gapped Architecture with Llamafile

```
┌────────────────────────────────────────────────────────────┐
│              Secure Facility (No Internet)                 │
│                                                            │
│  ┌──────────────────────────────────────────────────┐     │
│  │           Offline GEM Workstation                │     │
│  │                                                  │     │
│  │  ┌────────────────────────────────────────┐     │     │
│  │  │  llama-70b-medicare.llamafile         │     │     │
│  │  │  (40GB single executable)             │     │     │
│  │  │                                        │     │     │
│  │  │  • Model weights                      │     │     │
│  │  │  • Inference engine                   │     │     │
│  │  │  • Web server                         │     │     │
│  │  │  • API endpoints                      │     │     │
│  │  └────────────┬───────────────────────────┘     │     │
│  │               │ localhost:8080                  │     │
│  │  ┌────────────▼───────────────────────────┐     │     │
│  │  │  GEM Application (Python)              │     │     │
│  │  │  • Prompt engineering                  │     │     │
│  │  │  • Response parsing                    │     │     │
│  │  │  • Business logic                      │     │     │
│  │  └────────────┬───────────────────────────┘     │     │
│  │               │                                 │     │
│  │  ┌────────────▼───────────────────────────┐     │     │
│  │  │  Local Data Store                      │     │     │
│  │  │  • SQLite/PostgreSQL                   │     │     │
│  │  │  • Vector DB (Qdrant)                  │     │     │
│  │  │  • Policy documents                    │     │     │
│  │  └────────────────────────────────────────┘     │     │
│  └──────────────────────────────────────────────────┘     │
│                                                            │
│  Security Benefits:                                        │
│  ✓ Zero data exfiltration risk                            │
│  ✓ No cloud vendor access                                 │
│  ✓ HIPAA/FedRAMP compliant by design                     │
│  ✓ Works during internet outages                          │
└────────────────────────────────────────────────────────────┘
```

---

## Diagram 4: Multi-Agent Fraud Detection Network

```
                        ┌───────────────────┐
                        │  Suspicious       │
                        │  Claim Detected   │
                        └─────────┬─────────┘
                                  │
                        ┌─────────▼─────────┐
                        │   Orchestrator    │
                        │   Agent           │
                        │   (CrewAI)        │
                        └─────────┬─────────┘
                                  │
         ┌────────────────────────┼────────────────────────┐
         │                        │                        │
┌────────▼─────────┐   ┌─────────▼────────┐   ┌──────────▼────────┐
│ Medical Coding   │   │ Billing Patterns │   │ Network Analysis  │
│ Agent            │   │ Agent            │   │ Agent             │
│ (Claude-3.5)     │   │ (GPT-4o)         │   │ (GPT-4o)          │
│                  │   │                  │   │                   │
│ • CPT/ICD codes  │   │ • Statistical    │   │ • Provider links  │
│ • Medical        │   │   analysis       │   │ • Patient         │
│   necessity      │   │ • Peer           │   │   patterns        │
│ • Upcoding       │   │   benchmarks     │   │ • Fraud rings     │
└────────┬─────────┘   └─────────┬────────┘   └──────────┬────────┘
         │                        │                        │
         │                        │                        │
┌────────▼─────────┐   ┌─────────▼────────┐   ┌──────────▼────────┐
│ Provider         │   │ Temporal         │   │ Geographic        │
│ Credential Agent │   │ Anomaly Agent    │   │ Dispersion Agent  │
│ (GPT-4o-mini)    │   │ (GPT-4o)         │   │ (GPT-4o-mini)     │
│                  │   │                  │   │                   │
│ • NPI validation │   │ • Time-series    │   │ • Location        │
│ • Licenses       │   │ • Spikes         │   │   plausibility    │
│ • OIG exclusions │   │ • Cycles         │   │ • Travel patterns │
└────────┬─────────┘   └─────────┬────────┘   └──────────┬────────┘
         │                        │                        │
         └────────────────────────┼────────────────────────┘
                                  │
                        ┌─────────▼─────────┐
                        │   Synthesis       │
                        │   Agent           │
                        │   (GPT-4o)        │
                        │                   │
                        │ • Weighs evidence │
                        │ • Risk scoring    │
                        │ • Final decision  │
                        │ • Report gen.     │
                        └─────────┬─────────┘
                                  │
                        ┌─────────▼─────────┐
                        │ Fraud Detection   │
                        │ Report + Decision │
                        │                   │
                        │ Risk: HIGH/MED/LOW│
                        │ Action: Recommended│
                        │ Evidence: Detailed │
                        └───────────────────┘
```

---

## Diagram 5: MCPD Tool Orchestration for GEM

```
┌─────────────────────────────────────────────────────────────┐
│                    .mcpd.toml Configuration                 │
│  [servers.claims_db]                                        │
│  [servers.policy_rag]                                       │
│  [servers.nppes_lookup]                                     │
│  [servers.drug_database]                                    │
│  [servers.custom_validators]                                │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
          ┌───────────────────────┐
          │   mcpd daemon         │
          │   (HTTP Proxy)        │
          │   Port: 8090          │
          └───────────┬───────────┘
                      │
      ┌───────────────┼───────────────┐
      │               │               │
┌─────▼─────┐  ┌─────▼─────┐  ┌─────▼─────┐
│Claims DB  │  │Policy RAG │  │NPPES API  │
│MCP Server │  │MCP Server │  │MCP Server │
│           │  │           │  │           │
│PostgreSQL │  │Qdrant     │  │REST API   │
└─────┬─────┘  └─────┬─────┘  └─────┬─────┘
      │               │               │
      └───────────────┼───────────────┘
                      │
          ┌───────────▼───────────┐
          │   GEM Application     │
          │                       │
          │   Uses unified        │
          │   MCP interface       │
          │   for all tools       │
          └───────────────────────┘

Benefits:
• Single config file for all environments
• Secrets managed separately
• Language-agnostic tool support
• Easy dev → prod promotion
```

---

## Using These Diagrams

**For Presentation:**
1. Start with Diagram 1 (Stack Overview) for big picture
2. Show Diagram 2 (GEM Integration) for concrete application
3. Use Diagram 3-5 for specific use cases as needed

**Tools to Render:**
- Copy diagrams into Mermaid Live Editor (mermaid.live)
- Use ASCII diagram tools
- Create slides in PowerPoint/Keynote with shapes
- Use draw.io for professional diagrams

**Customization:**
- Adjust based on your specific GEM architecture
- Add actual NPI numbers, database names for realism
- Include cost estimates per layer

# Lumigator Voiceover Script
**Duration:** 5 minutes  
**Visual Aid:** Lumigator UI + evaluation results dashboard

---

## Opening (25 seconds)
"Lumigator is Mozilla's LLM evaluation platform. The name combines 'LLM' with 'Navigator' - it helps you navigate the overwhelming landscape of language models to find the right one for your specific use case. With hundreds of available models, evaluation is no longer optional - it's essential."

## The Evaluation Challenge (50 seconds)
"For GEM, we face specific evaluation challenges:

**Model Selection Paralysis**: Should we use GPT-4, Claude 3.5, Llama 3, Mistral Large, or Gemini Pro? They all claim to be good, but which is best for Medicare claim validation?

**Task-Specific Performance**: Benchmarks like MMLU or HumanEval don't tell us how models perform on medical coding, fraud detection, or policy interpretation.

**Bias and Fairness**: Does a model make consistent decisions across different patient demographics, geographic regions, or provider types? This is critical for CMS's equity requirements.

**Cost vs Performance Tradeoffs**: Maybe GPT-4 is 2% more accurate but costs 10x more. Is that worth it?

**Model Drift**: When OpenAI updates GPT-4, does performance on our tasks improve or degrade? We need continuous evaluation.

Lumigator provides a framework for answering these questions with data instead of guesses."

## How Lumigator Works (60 seconds)
"Lumigator guides you through a structured evaluation process:

**Step 1: Define Your Task**
Currently supports summarization and translation, with more tasks coming. For FPS2, we'd want claim classification, policy interpretation, and fraud detection tasks.

**Step 2: Create Evaluation Dataset**
You provide examples of inputs and expected outputs. For GEM, this would be historical claims with known correct decisions. Lumigator helps you sample diverse examples to avoid bias.

**Step 3: Select Models to Evaluate**
Choose from commercial models (OpenAI, Anthropic, Google) or local models (via Llamafile or Ollama). Lumigator handles the infrastructure for running evaluations across all selected models.

**Step 4: Run Evaluation**
Lumigator processes your dataset through each model, measuring:
- **Accuracy**: How often does the model make the correct decision?
- **Latency**: How long does each inference take?
- **Cost**: What's the total cost based on each provider's pricing?
- **Consistency**: Does the model give the same answer for similar inputs?

**Step 5: Analyze Results**
The dashboard shows you head-to-head comparisons. You can drill down into specific examples where models disagree, helping you understand their different reasoning patterns."

## Bias Detection (45 seconds)
"One of Lumigator's critical features is bias detection. For Medicare claims, we need to ensure our models don't discriminate based on:
- Patient demographics (age, gender, ethnicity)
- Geographic location (urban vs rural, different states)
- Provider characteristics (small practices vs large hospitals)

Lumigator can stratify results across these dimensions. You might discover that a model performs well overall but has significantly worse accuracy for claims from rural providers or for specific age groups. This is exactly the kind of hidden bias that CMS oversight would flag.

Being able to detect and document this bias proactively is crucial for both regulatory compliance and public trust."

## Integration with Development Workflow (40 seconds)
"Lumigator integrates directly with the Mozilla AI stack:

- Use **AnyLLM** to evaluate models from different providers without code changes
- Test **AnyAgent** workflows end-to-end, not just individual models
- Compare results with and without **AnyGuardrail** to measure the safety/accuracy tradeoff
- Evaluate models packaged as **Llamafiles** to verify they match cloud provider performance

It's designed to work with your existing code, not replace it."

## FPS2 Implementation Roadmap (50 seconds)
"Here's how I envision using Lumigator for FPS2:

**Phase 1: Baseline GEM Performance**
Evaluate GEM's current model against alternatives. Establish baseline accuracy, latency, and cost metrics.

**Phase 2: Task Decomposition**
GEM does multiple things - claim validation, fraud scoring, policy interpretation. Evaluate specialized models for each task. Maybe Claude is better for policy interpretation while GPT-4o-mini is sufficient for basic validation.

**Phase 3: Continuous Monitoring**
Set up automated evaluation pipelines. When providers release new model versions, automatically run them through our test suite. Track performance over time.

**Phase 4: Fairness Auditing**
Build comprehensive bias detection into our evaluation. Document model behavior across all relevant demographic and geographic dimensions for CMS reporting.

**Phase 5: Cost Optimization**
Use evaluation data to optimize our model selection strategy. Route complex cases to expensive models, routine cases to cheaper ones."

## Developer Experience (10 seconds)
"Lumigator is designed to be approachable for developers who aren't ML specialists. You don't need to understand BLEU scores or perplexity - it translates technical metrics into actionable business insights."

---

## Key Talking Points to Emphasize
- **Data-Driven Decisions**: Stop guessing, start measuring
- **Bias Detection**: Critical for CMS compliance and equity
- **Cost Optimization**: Make informed cost/accuracy tradeoffs
- **Continuous Monitoring**: Track model performance over time
- **Transparency**: Understand why models make specific decisions

## Transition to Next Section
"Now that we've covered all eight Mozilla AI tools, let's tie this together with specific FPS2 use cases..."

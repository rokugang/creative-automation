#!/usr/bin/env python3
"""
AnyLLM Provider Switching Demo
Demonstrates how easy it is to switch between LLM providers

Time Required: 2-3 minutes
Prerequisites: 
  - pip install any-llm-sdk[openai,anthropic,mistral]
  - Set environment variables: OPENAI_API_KEY, ANTHROPIC_API_KEY, MISTRAL_API_KEY
"""

import os
import time
from any_llm import completion

# Demo configuration
DEMO_PROMPT = """Analyze this Medicare claim for potential issues:

Provider: Dr. Smith (NPI: 1234567890)
Patient: Medicare ID ***-**-6789
Service Date: 2024-01-15
CPT Code: 99215 (Office visit, established patient, high complexity)
Diagnosis: Z23 (Encounter for immunization)
Billed Amount: $250

Is there a billing issue here?"""


def print_separator(char="=", length=70):
    """Print a visual separator"""
    print(char * length)


def demo_provider_switch():
    """Main demo function"""
    
    print_separator("=")
    print("AnyLLM Provider Switching Demo")
    print("Demonstrating vendor flexibility for GEM")
    print_separator("=")
    print()
    
    # Check which providers are available
    available_providers = []
    if os.getenv("OPENAI_API_KEY"):
        available_providers.append("openai")
    if os.getenv("ANTHROPIC_API_KEY"):
        available_providers.append("anthropic")
    if os.getenv("MISTRAL_API_KEY"):
        available_providers.append("mistral")
    
    if not available_providers:
        print("⚠️  No API keys found. Please set environment variables:")
        print("   - OPENAI_API_KEY")
        print("   - ANTHROPIC_API_KEY")
        print("   - MISTRAL_API_KEY")
        return
    
    print(f"✓ Found API keys for: {', '.join(available_providers)}")
    print()
    
    # Demo: Same code, different providers
    providers_to_test = [
        {
            "name": "OpenAI GPT-4o-mini",
            "model": "gpt-4o-mini",
            "provider": "openai",
            "available": "openai" in available_providers
        },
        {
            "name": "Anthropic Claude 3.5 Sonnet",
            "model": "claude-3-5-sonnet-20241022",
            "provider": "anthropic",
            "available": "anthropic" in available_providers
        },
        {
            "name": "Mistral Large",
            "model": "mistral-large-latest",
            "provider": "mistral",
            "available": "mistral" in available_providers
        }
    ]
    
    results = []
    
    for provider_config in providers_to_test:
        if not provider_config["available"]:
            print(f"⏭️  Skipping {provider_config['name']} (no API key)")
            print()
            continue
        
        print_separator("-")
        print(f"Testing: {provider_config['name']}")
        print_separator("-")
        
        start_time = time.time()
        
        try:
            # THE MAGIC: Same function call, different provider!
            response = completion(
                model=provider_config["model"],
                provider=provider_config["provider"],
                messages=[{
                    "role": "user",
                    "content": DEMO_PROMPT
                }],
                temperature=0.3  # Low temperature for consistency
            )
            
            elapsed_time = time.time() - start_time
            
            # Extract response
            content = response.choices[0].message.content
            
            # Show results
            print(f"⏱️  Response time: {elapsed_time:.2f} seconds")
            print(f"📊 Tokens used: ~{response.usage.total_tokens if hasattr(response.usage, 'total_tokens') else 'N/A'}")
            print()
            print("Response:")
            print(content[:400] + "..." if len(content) > 400 else content)
            print()
            
            results.append({
                "provider": provider_config["name"],
                "time": elapsed_time,
                "success": True
            })
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            print()
            results.append({
                "provider": provider_config["name"],
                "time": 0,
                "success": False
            })
    
    # Summary
    print_separator("=")
    print("Demo Summary")
    print_separator("=")
    print()
    print("Key Takeaway: We used the SAME CODE with different providers.")
    print("Only changed: provider='openai' → provider='anthropic' → provider='mistral'")
    print()
    
    if len([r for r in results if r["success"]]) > 1:
        print("Performance Comparison:")
        for result in results:
            if result["success"]:
                print(f"  • {result['provider']}: {result['time']:.2f}s")
        print()
    
    print("For FPS2/GEM, this means:")
    print("  ✓ No vendor lock-in")
    print("  ✓ Easy A/B testing")
    print("  ✓ Cost optimization (route to cheapest adequate model)")
    print("  ✓ Automatic failover during outages")
    print("  ✓ Future-proof (new providers added easily)")
    print()


def demo_cost_optimization():
    """Demonstrate intelligent model routing"""
    
    print_separator("=")
    print("Bonus: Cost Optimization Strategy")
    print_separator("=")
    print()
    
    print("GEM can route claims intelligently:")
    print()
    
    # Simulated claim complexity assessment
    claims = [
        {"id": "CLM001", "complexity": "low", "description": "Routine checkup"},
        {"id": "CLM002", "complexity": "medium", "description": "Multiple diagnoses"},
        {"id": "CLM003", "complexity": "high", "description": "Rare condition, complex billing"}
    ]
    
    for claim in claims:
        # Route based on complexity
        if claim["complexity"] == "low":
            model_choice = {"model": "gpt-4o-mini", "provider": "openai", "cost": "$0.02"}
        elif claim["complexity"] == "medium":
            model_choice = {"model": "claude-3-5-sonnet", "provider": "anthropic", "cost": "$0.08"}
        else:
            model_choice = {"model": "gpt-4o", "provider": "openai", "cost": "$0.15"}
        
        print(f"Claim {claim['id']} ({claim['complexity']} complexity):")
        print(f"  → Route to: {model_choice['model']} (est. {model_choice['cost']} per claim)")
        print()
    
    print("Estimated savings: 40-60% vs. always using GPT-4")
    print()


if __name__ == "__main__":
    try:
        # Main demo
        demo_provider_switch()
        
        # Bonus content
        demo_cost_optimization()
        
        print_separator("=")
        print("Demo Complete!")
        print("Questions?")
        print_separator("=")
        
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user.")
    except Exception as e:
        print(f"\n\n❌ Demo error: {str(e)}")
        print("This is a demonstration script. Please ensure:")
        print("  1. any-llm-sdk is installed")
        print("  2. API keys are set in environment variables")

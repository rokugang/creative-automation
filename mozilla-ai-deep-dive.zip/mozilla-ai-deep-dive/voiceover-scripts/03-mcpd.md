# MCPD Voiceover Script
**Duration:** 2.5 minutes  
**Visual Aid:** Configuration file + architecture diagram

---

## Opening (20 seconds)
"MCPD - which stands for Model Context Protocol Daemon - is Mozilla's tool for declaratively managing MCP servers. If you're familiar with requirements.txt for Python packages, MCPD is essentially 'requirements.txt for AI tools'. It bridges the gap between local development and production deployment."

## Understanding MCP First (30 seconds)
"Let me quickly explain MCP, or Model Context Protocol. It's an open standard developed by Anthropic for connecting AI agents to external tools and data sources. Think of it as a standardized way for language models to interact with databases, APIs, file systems, search engines, and more.

The challenge is that managing these tool servers across different environments - from your laptop to staging to production - gets complicated fast. Different configurations, different secrets, different dependencies."

## How MCPD Solves This (45 seconds)
"MCPD introduces declarative configuration through a simple `.mcpd.toml` file. Here's what a configuration looks like:

```toml
[servers.database]
image = \"mcp-server-postgres\"
args = [\"--connection-string\", \"$DATABASE_URL\"]

[servers.search]
command = \"npx\"
args = [\"@modelcontextprotocol/server-brave-search\"]
env = { \"BRAVE_API_KEY\" = \"$BRAVE_KEY\" }

[servers.filesystem]
command = \"uvx\"
args = [\"mcp-server-filesystem\", \"--allowed-paths\", \"/data/claims\"]
```

With one command - `mcpd daemon` - all these tools start running and become available to your AI agents through a unified HTTP proxy."

## Key Features (40 seconds)
"Four critical features make MCPD production-ready:

**Language Agnostic**: Run Python servers, Node.js servers, or Docker containers side-by-side.

**Secrets Management**: Separate configuration from runtime secrets. Export templates for UAT and production without committing sensitive data to Git.

**Zero Configuration for Developers**: Just run `mcpd add <tool-name>` and it handles installation and setup.

**Environment Promotion**: The same .mcpd.toml file works locally, in CI, and in cloud deployments without modification."

## FPS2/GEM Use Case (35 seconds)
"For GEM, MCPD orchestrates our entire tool ecosystem:

- **Database Access**: Connect to claims databases securely
- **Document Retrieval**: RAG tools for accessing Medicare policy documents
- **External APIs**: NPPES provider lookups, drug databases
- **Custom Tools**: FPS-specific validation logic

When a data scientist develops GEM locally, they use the same tool configuration that runs in production. Operations teams get a single file to deploy, with clear secrets management. No more 'it works on my machine' problems."

## Looking Forward (10 seconds)
"Mozilla is developing a Kubernetes operator for MCPD, which will make it even easier to deploy and scale tool servers in production clusters."

---

## Key Talking Points to Emphasize
- **Declarative**: Infrastructure as code for AI tools
- **Reproducible**: Same config, same behavior everywhere
- **Secure**: Secrets never committed to version control
- **DevOps Friendly**: Operations teams can deploy without understanding Python/Node.js
- **Scales**: From laptop to production clusters

## Transition to Next Section
"While MCPD handles tool orchestration, we also need lightweight, embeddable models for specific tasks. That's where EncoderFile comes in..."

# AnyAgent Voiceover Script
**Duration:** 3 minutes  
**Visual Aid:** Agent framework comparison + workflow diagram

---

## Opening (20 seconds)
"AnyAgent is Mozilla's abstraction layer for AI agent frameworks. It lets you build agents using a single interface, then easily swap between frameworks like LangChain, CrewAI, or Anthropic's SDK - or even use multiple frameworks in the same application."

## Understanding the Agent Framework Landscape (40 seconds)
"The AI agent ecosystem is fragmented right now. You have:
- **LangChain**: The most popular, Python-based, with a huge ecosystem
- **CrewAI**: Focused on multi-agent collaboration
- **LlamaIndex**: Optimized for retrieval and data integration
- **Anthropic SDK**: Direct integration with Claude's tool use
- **AutoGen**: Microsoft's framework for multi-agent conversations

Each has different strengths, different APIs, and different design philosophies. Building on one means committing to it - until now."

## How AnyAgent Solves This (45 seconds)
"AnyAgent provides a unified interface:

```python
from any_agent import AnyAgent, AgentConfig
from any_agent.tools import search_web, query_database

# Create an agent with any framework
agent = AnyAgent.create(
    \"langchain\",  # or \"crewai\", \"tinyagent\", etc.
    AgentConfig(
        model_id=\"openai:gpt-4o\",
        instructions=\"Validate Medicare claims for fraud indicators\",
        tools=[search_web, query_database]
    )
)

# Run the agent
response = agent.run(\"Analyze claim #123456 for unusual patterns\")
```

Want to try CrewAI instead? Change \"langchain\" to \"crewai\". Everything else stays the same."

## Key Features (40 seconds)
"AnyAgent includes four critical capabilities:

**Tools Integration**: Unified tool interface that works across frameworks. Define a tool once, use it everywhere.

**MCP Support**: Native integration with Model Context Protocol, so tools managed by MCPD are automatically available.

**Tracing**: Built-in observability. See exactly what your agent is doing at each step - which tools it calls, what reasoning it performs, how long each step takes.

**Evaluation**: Compare frameworks head-to-head on your specific tasks. Which framework is better at processing Medicare claims? AnyAgent helps you measure and decide."

## FPS2/GEM Use Case (50 seconds)
"For FPS2, AnyAgent enables sophisticated claim validation workflows:

**Multi-Step Validation Agent**: 
1. Retrieve claim details from database
2. Search Medicare policy documents for relevant coverage rules
3. Check provider credentials through NPPES API
4. Compare against historical claims patterns
5. Generate validation decision with reasoning

**Framework Selection Based on Task**:
- Use LangChain for complex reasoning chains with many tools
- Use CrewAI when you need multiple specialized agents (one for medical coding, one for billing rules, one for provider verification) working together
- Use TinyAgent for simple, fast decisions that don't need the overhead

**A/B Testing in Production**: Run 10% of claims through LangChain, 10% through CrewAI, 80% through your current system. Measure accuracy, latency, and cost to make data-driven framework decisions."

## Integration with Other Mozilla Tools (20 seconds)
"AnyAgent works seamlessly with the rest of the stack:
- Uses **AnyLLM** for flexible model selection
- Integrates **AnyGuardrail** for safety checks
- Connects to **MCPD** for tool orchestration
- Can call **EncoderFiles** as specialized tools

It's the orchestration layer that ties everything together."

## Evaluation and Observability (15 seconds)
"The built-in tracing is invaluable for debugging. When a claim gets incorrectly flagged, you can see the exact reasoning chain, which tools were called, and what data was used. This makes root cause analysis straightforward."

---

## Key Talking Points to Emphasize
- **Framework Agnostic**: Don't lock into one framework too early
- **Experimentation**: Easy to test different approaches
- **Production Ready**: Includes tracing, error handling, and evaluation
- **Ecosystem Integration**: Works with all the other Mozilla AI tools
- **Future-Proof**: As new frameworks emerge, AnyAgent will support them

## Transition to Next Section
"Now, while we can build agents from scratch, Mozilla also provides pre-built workflows through Blueprints..."

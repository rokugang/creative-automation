# AnyLLM Voiceover Script
**Duration:** 2 minutes  
**Visual Aid:** Code examples + cost comparison chart

---

## Opening (15 seconds)
"AnyLLM is Mozilla's answer to vendor lock-in. It provides a single, unified API to work with any LLM provider - OpenAI, Anthropic, Google, Mistral, AWS Bedrock, Azure, or even local models through Ollama."

## The Problem It Solves (30 seconds)
"Right now, if you build an application using OpenAI's API and want to switch to Claude or Gemini, you need to rewrite your code. Each provider has different SDKs, different parameter names, different error handling. This creates technical debt and makes it expensive to optimize costs or performance.

AnyLLM solves this with a provider-agnostic interface. Write your code once, switch providers by changing a single string."

## Code Example Walkthrough (45 seconds)
"Let me show you how simple this is:

```python
from any_llm import completion

# Using OpenAI
response = completion(
    model='gpt-4o',
    provider='openai',
    messages=[{'role': 'user', 'content': 'Analyze this claim'}]
)

# Want to switch to Claude? Just change the provider:
response = completion(
    model='claude-3-5-sonnet',
    provider='anthropic',
    messages=[{'role': 'user', 'content': 'Analyze this claim'}]
)
```

Same function, same parameters, different provider. Your application logic doesn't change at all."

## FPS2/GEM Use Case (40 seconds)
"For GEM, this enables powerful cost optimization and reliability strategies:

**Multi-Provider Strategy**: Use GPT-4 for complex claim edits requiring deep reasoning, but Claude for straightforward classification tasks where it's faster and cheaper.

**Automatic Failover**: If OpenAI experiences an outage, automatically route requests to Anthropic without code changes.

**A/B Testing**: Compare model performance on real Medicare claims data. Which model is better at detecting incorrect CPT codes? Run both in parallel and measure.

**Budget Management**: The optional AnyLLM Gateway adds cost tracking, rate limiting, and budget controls across all providers from one dashboard."

## Technical Benefits (10 seconds)
"AnyLLM leverages official provider SDKs, ensuring maximum compatibility. It includes full type hints for better IDE support and provides clear, actionable error messages."

---

## Key Talking Points to Emphasize
- **Flexibility**: Never locked into one vendor
- **Cost Optimization**: Choose the most cost-effective model for each task
- **Reliability**: Multi-provider redundancy
- **Future-Proof**: New providers added without breaking your code
- **Production-Ready**: Powers Mozilla's own agent tools

## Transition to Next Section
"AnyLLM helps us manage models, but what about managing tools and external resources? That's where MCPD provides crucial infrastructure..."

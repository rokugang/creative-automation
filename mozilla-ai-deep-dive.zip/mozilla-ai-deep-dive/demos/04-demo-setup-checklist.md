# Demo Setup Checklist
**Complete these tasks BEFORE your Friday deep dive session**

---

## Pre-Presentation Setup (Do 1 Day Before)

### 1. Llamafile Demo Setup

**Downloads (Large files - do NOT wait until presentation!):**
```bash
# Create demo directory
mkdir -p ~/mozilla-ai-demos/llamafile
cd ~/mozilla-ai-demos/llamafile

# Download a small, fast model for demo
curl -LO https://huggingface.co/Mozilla/Phi-3-mini-4k-instruct-llamafile/resolve/main/phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Make executable
chmod +x phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Test run (should start server at localhost:8080)
./phi-3-mini-4k-instruct.Q4_K_M.llamafile

# Stop after confirming it works (Ctrl+C)
```

**Estimated download time:** 10-15 minutes  
**File size:** ~2.3GB

**Backup plan:** If download fails or file is corrupted, have a pre-recorded video

---

### 2. AnyLLM Demo Setup

**Install dependencies:**
```bash
# Create virtual environment
python3 -m venv ~/mozilla-ai-demos/anyllm-env
source ~/mozilla-ai-demos/anyllm-env/bin/activate

# Install any-llm with multiple providers
pip install 'any-llm-sdk[openai,anthropic,mistral]'

# Copy demo script
cp mozilla-ai-deep-dive/demos/02-anyllm-provider-switching.py ~/mozilla-ai-demos/
```

**Set up API keys:**
```bash
# Add to your shell profile or set before demo
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export MISTRAL_API_KEY="..."

# Test connectivity
python3 -c "from any_llm import completion; print('AnyLLM installed successfully')"
```

**Budget check:** 
- Each demo run costs ~$0.10-0.20
- Run 2-3 test runs before presentation
- Total cost: < $1

---

### 3. AnyGuardrail Demo Setup

**Install dependencies:**
```bash
# Use same virtual environment
source ~/mozilla-ai-demos/anyllm-env/bin/activate

# Install any-guardrail
pip install any-guardrail

# Copy demo script
cp mozilla-ai-deep-dive/demos/03-anyguardrail-safety-demo.py ~/mozilla-ai-demos/
```

**Note:** This demo can run in "simulation mode" without actual guardrail API keys. The script handles this gracefully.

**Test run:**
```bash
cd ~/mozilla-ai-demos
python3 03-anyguardrail-safety-demo.py
```

---

### 4. Presentation Materials

**Organize files:**
```bash
# Create presentation folder
mkdir -p ~/mozilla-ai-presentation

# Copy key documents
cp mozilla-ai-deep-dive/00-PRESENTATION-OVERVIEW.md ~/mozilla-ai-presentation/
cp -r mozilla-ai-deep-dive/voiceover-scripts ~/mozilla-ai-presentation/
cp -r mozilla-ai-deep-dive/diagrams ~/mozilla-ai-presentation/

# Create quick reference
cat > ~/mozilla-ai-presentation/QUICK-REFERENCE.md << 'EOF'
# Quick Reference for Presentation

## Demo Locations
- Llamafile: ~/mozilla-ai-demos/llamafile/
- AnyLLM: ~/mozilla-ai-demos/02-anyllm-provider-switching.py
- AnyGuardrail: ~/mozilla-ai-demos/03-anyguardrail-safety-demo.py

## Important URLs
- Llamafile docs: https://mozilla-ai.github.io/llamafile/
- AnyLLM docs: https://mozilla-ai.github.io/any-llm/
- AnyGuardrail docs: https://github.com/mozilla-ai/any-guardrail
- Blueprints: https://blueprints.mozilla.ai/
- MCPD docs: https://mozilla-ai.github.io/mcpd/

## Time Allocations
- Llamafile demo: 2.5 min
- AnyLLM demo: 2 min
- AnyGuardrail demo: 2.5 min
- Q&A buffer: 5 min
EOF
```

---

## Day-of-Presentation Checklist

### Morning Setup (2 Hours Before)

- [ ] **Charge laptop fully** - demos use CPU intensively
- [ ] **Close unnecessary applications** - free up RAM for Llamafile
- [ ] **Test internet connection** - needed for AnyLLM demo
- [ ] **Open all demo scripts in terminal windows** - ready to run
- [ ] **Pre-load browser tabs:**
  - [ ] http://localhost:8080 (for Llamafile)
  - [ ] https://github.com/mozilla-ai/llamafile
  - [ ] https://blueprints.mozilla.ai/
  - [ ] https://mozilla-ai.github.io/mcpd/
- [ ] **Print voiceover scripts** - as backup reference
- [ ] **Test screen sharing** - if presenting remotely
- [ ] **Verify API keys are set** - `echo $OPENAI_API_KEY`
- [ ] **Run each demo once** - confirm everything works

### Terminal Setup

Create 4 terminal windows, each with:

**Terminal 1: Llamafile Demo**
```bash
cd ~/mozilla-ai-demos/llamafile
# Ready to run: ./phi-3-mini-4k-instruct.Q4_K_M.llamafile
```

**Terminal 2: AnyLLM Demo**
```bash
cd ~/mozilla-ai-demos
source anyllm-env/bin/activate
# Ready to run: python3 02-anyllm-provider-switching.py
```

**Terminal 3: AnyGuardrail Demo**
```bash
cd ~/mozilla-ai-demos
source anyllm-env/bin/activate
# Ready to run: python3 03-anyguardrail-safety-demo.py
```

**Terminal 4: General Purpose**
```bash
# For any ad-hoc commands or showing file listings
```

---

## Backup Plans

### If Llamafile Doesn't Start
**Symptoms:** Port conflict, insufficient RAM, file corruption

**Solution 1:** Use different port
```bash
./phi-3-mini-4k-instruct.Q4_K_M.llamafile --port 8081
```

**Solution 2:** Show pre-recorded video  
Location: `~/mozilla-ai-demos/backup-videos/llamafile-demo.mp4`

### If API Keys Don't Work
**Symptoms:** Authentication errors during AnyLLM demo

**Solution:** Demo switches to showing code and explaining conceptually. The code example is self-explanatory even without running it.

### If Internet Is Down
**Symptoms:** Can't reach OpenAI/Anthropic APIs

**Solution:** This actually makes the Llamafile demo MORE impressive! Emphasize that Llamafile works offline while others don't.

### If Laptop Crashes
**Symptoms:** Everything fails

**Solution:** Have presentation materials accessible via:
1. Backup laptop
2. Shared Google Drive link
3. USB drive with all materials

---

## Post-Demo Actions

### If Audience Wants Hands-On
```bash
# Share quick start commands
cat > ~/mozilla-ai-presentation/QUICKSTART-FOR-TEAM.md << 'EOF'
# Quick Start for Team Members

## Try Llamafile Yourself
curl -LO https://huggingface.co/Mozilla/Phi-3-mini-4k-instruct-llamafile/resolve/main/phi-3-mini-4k-instruct.Q4_K_M.llamafile
chmod +x phi-3-mini-4k-instruct.Q4_K_M.llamafile
./phi-3-mini-4k-instruct.Q4_K_M.llamafile

## Try AnyLLM
pip install 'any-llm-sdk[openai]'
export OPENAI_API_KEY="your-key"
python3 -c "from any_llm import completion; print(completion(model='gpt-4o-mini', provider='openai', messages=[{'role':'user','content':'Hello!'}]))"

## Resources
- Full documentation: [Internal Confluence link]
- Demo repository: [Git repository]
- Office hours: Fridays 2-3pm
EOF
```

### Follow-Up Materials
- [ ] Share demo scripts via Git repository
- [ ] Post documentation links to team Slack
- [ ] Schedule office hours for implementation questions
- [ ] Create Confluence page with detailed setup guides

---

## Troubleshooting Quick Reference

| Problem | Quick Fix |
|---------|-----------|
| Llamafile port conflict | Add `--port 8081` |
| Llamafile slow | Expected on older hardware, mention this |
| Python import errors | `pip install` again, check virtual env |
| API key errors | Check with `echo $OPENAI_API_KEY` |
| Out of RAM | Close other applications |
| Demo hangs | Have backup terminal ready, kill process |

---

## Estimated Timing

| Activity | Time |
|----------|------|
| Pre-presentation setup (day before) | 30-45 min |
| Morning-of testing | 15-20 min |
| Terminal window setup | 5 min |
| **Total prep time** | **60-80 min** |

---

## Success Metrics

After the presentation, you should be able to answer "yes" to:
- [ ] Audience understood each tool's purpose
- [ ] At least one demo ran successfully live
- [ ] Q&A revealed genuine interest
- [ ] 2+ team members want to try tools themselves
- [ ] Leadership sees value for FPS2/GEM

---

## Emergency Contacts

If you need help during setup:
- **Mozilla AI Discord:** https://discord.com/invite/WKyCEEHd7U
- **GitHub Issues:** Each tool's repository
- **Internal team:** [Your tech lead's contact]

---

## Final Pre-Presentation Check (15 min before)

```bash
# Run this comprehensive check
cat > ~/mozilla-ai-demos/preflight-check.sh << 'EOF'
#!/bin/bash
echo "Mozilla AI Demo Preflight Check"
echo "================================"
echo ""

echo "1. Checking Llamafile..."
if [ -f ~/mozilla-ai-demos/llamafile/*.llamafile ]; then
    echo "   ✓ Llamafile present"
else
    echo "   ✗ Llamafile missing!"
fi

echo "2. Checking Python environment..."
if source ~/mozilla-ai-demos/anyllm-env/bin/activate 2>/dev/null; then
    echo "   ✓ Virtual environment OK"
    python3 -c "import any_llm" && echo "   ✓ AnyLLM installed" || echo "   ✗ AnyLLM missing"
    python3 -c "import any_guardrail" && echo "   ✓ AnyGuardrail installed" || echo "   ✗ AnyGuardrail missing"
else
    echo "   ✗ Virtual environment not found!"
fi

echo "3. Checking API keys..."
[ -n "$OPENAI_API_KEY" ] && echo "   ✓ OpenAI key set" || echo "   ⚠ OpenAI key not set"
[ -n "$ANTHROPIC_API_KEY" ] && echo "   ✓ Anthropic key set" || echo "   ⚠ Anthropic key not set"

echo "4. Checking disk space..."
df -h ~ | tail -1 | awk '{print "   Free space: " $4}'

echo ""
echo "Preflight check complete!"
EOF

chmod +x ~/mozilla-ai-demos/preflight-check.sh
~/mozilla-ai-demos/preflight-check.sh
```

Good luck with your presentation! 🚀
